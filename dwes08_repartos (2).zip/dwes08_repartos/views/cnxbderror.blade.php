@extends('app') 
@section('title') Conexion BD
@endsection
 
 
@section('contenido')
<p>Error de conexión a la BBDD. Inténtelo más tarde<p>
@endsection